#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>
#include<time.h>
#include<ctype.h>

int nodeCount=0;

typedef struct trieNode
{
    struct trieNode *children[26];
    char character;
    bool endOfWord;
}trieNode;

int getCharIndex(char c)
{ 
   if((int)c >= 65 && (int)c <= 90){
     return tolower(c)-'a';  
   }else if( (int)c >= 97 && (int)c <= 122){
     return c-'a';
   }else
     return -1;
}

trieNode* createNode()
{
    trieNode* newtrieNode = (trieNode*)malloc(sizeof(trieNode));
    newtrieNode->character='#';
    newtrieNode->endOfWord = false;
    int i;
    for (i = 0; i<26; i++)
    {
    	newtrieNode->children[i] = NULL;
    }
    return newtrieNode;
}

void insertWord(trieNode *root,char *word)
{
    int i,charIndex;
    trieNode* newNode = root;
    for(i=0;i<strlen(word)-1;i++)
    {
        charIndex = getCharIndex(word[i]);
        if(charIndex >= 0){
        if(newNode->children[charIndex] == NULL)
        {
            newNode->children[charIndex] = createNode();
            newNode->children[charIndex]->character = word[i];

        }
            newNode = newNode->children[charIndex];
        }
    }
    newNode->endOfWord = true;
    nodeCount = nodeCount+1;
}

trieNode* fileReader(char* fileName)
{
    char word[100];
    FILE *fp = fopen(fileName,"r");
    if (fp == NULL)
    {
        printf("Unable to open the file");
        exit(1);
    }
    trieNode* root = createNode();
    root->character = '/';
    clock_t begin = clock();
    while(1)
    {
        fgets(word,100,fp);
        insertWord(root,word);
        if(feof(fp))
            break;
    }
    clock_t end = clock();
    double time_spent = (double)(end-begin)/CLOCKS_PER_SEC;
    printf("Insertion Time: %.8lf s\n",time_spent);
    fclose(fp);
    return root;
}

trieNode* searchNodes(trieNode* root,char* word)
{
    int i,charIndex;
    trieNode* currentNode = root;
    for(i=0;i<strlen(word);i++)
    {
        charIndex = getCharIndex(word[i]);
        if(currentNode != NULL)
          currentNode =currentNode->children[charIndex];
    }
    return currentNode;
}

void printSuggetions(trieNode* suggestedNode,char wordBuffer[],int bufferSize)
{
    int i,charIndex;
    if(suggestedNode->endOfWord)
    {
        for(i=0;i<bufferSize;i++)
        {
            printf("%c",wordBuffer[i]);
        }
        printf("\n");
    }
    for(i=0;i<26;i++)
    {
        if(suggestedNode->children[i]!=NULL)
        {
            wordBuffer[bufferSize] = suggestedNode->children[i]->character;
            printSuggetions(suggestedNode->children[i],wordBuffer,bufferSize+1);
        }
    }
}

int main()
{
    char text[100];
    int i = 0; 
    trieNode* root = fileReader("wordlist70000.txt");
    printf("Memory: %lu Bytes\n\n",sizeof(*(root))*nodeCount);

    while(1)
    {
        printf("Enter keyword: ");
        scanf("%s",&text[i]);
        char str[100];
        strcpy(str,text);
        trieNode* suggestedNode = searchNodes(root,str);
        printf("\n");
        if(suggestedNode != NULL){
           clock_t begin = clock();
           printSuggetions(suggestedNode,str,strlen(str));
           clock_t end = clock();
           double elapsed_time = (double)(end-begin)/CLOCKS_PER_SEC;
           printf("\nElapsed time: %f s\n",elapsed_time);
           printf("\n");
        }else{
           printf("No Matching Suggestions\n\n");
        }
  
    }
    return 0;
}
